/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class CalculatorImplement implements Calculator{

    @Override
    public int calculateTotal(NoteBundle enteredNotes) { 
        return enteredNotes.getTotal();
    }

    @Override
    public NoteBundle calculateChange(float amountChange) {
       NoteBundle change = new NoteBundle(new int[5]);
       int remainingAmount = (int) amountChange;
       
       change.number200ThousandNotes = remainingAmount / 200;
       remainingAmount = remainingAmount % 200;
       
       change.number100ThousandNotes = remainingAmount / 100;
       remainingAmount = remainingAmount % 100;
       
       change.number50ThousandNotes = remainingAmount / 50;
       remainingAmount = remainingAmount % 50;
       
       change.number20ThousandNotes = remainingAmount / 20;
       remainingAmount = remainingAmount % 20;
       
       change.number10ThousandNotes = remainingAmount / 10;
       remainingAmount = remainingAmount % 10;
       
       return change;
       
       
    }
    
}
