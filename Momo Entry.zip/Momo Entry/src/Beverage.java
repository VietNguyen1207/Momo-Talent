/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public enum Beverage {
    COKE(1,10),Pepsi(2,10),Soda(3,20);
    
    private int id;
    private float price;
    
    Beverage(int id, float price){
        this.id = id;
        this.price = price;
    }
    
    public int getId(){
        return this.id;
    }
    
    public float getPrice(){
        return this.price;
    }
    
    public static Beverage valueOf(int beverageSelected){
        for (Beverage beverage : Beverage.values()) {
            if (beverageSelected == beverage.getId()) {
                return beverage;
            }
        }
        return null;
    }
}
