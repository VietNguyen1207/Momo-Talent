/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public enum Note {
    TEN_THOUSANDS(10), TWENTY_THOUSAND(20), FIFTY_THOUSAND(50), HUNDRED_THOUSAND(100), TWO_HUNDRED_THOUSANDS(200);
    
    private float value;
    
    private Note(float value){
        this.value = value;
    }
    
    public float getValue(){
        return this.value;
    }
    
    public static int[] parseNotes(String notes){
        String[] numberNotesInText = notes.split(",");
        int[] result = new int[numberNotesInText.length];
        
        for(int index= 0; index < numberNotesInText.length; index++){
            result[index] = Integer.parseInt(numberNotesInText[index]);
        }
        return result;
    }
}
