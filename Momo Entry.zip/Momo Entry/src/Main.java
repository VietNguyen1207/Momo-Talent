
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Admin
 */
public class Main {

    public static void main(String[] args) {
        //to recei input from user
        Scanner scanner = new Scanner(System.in);
        //
        VendingMachine vendingMachine =  new VendingMachineImplement();
        vendingMachine.displayBeverage();
        //beverage selected by users
        String selectedBeverage = scanner.nextLine();
        //convert selected beverage to integer to parse into vending machine
        int selectBeverageNumber = Integer.parseInt(selectedBeverage);
        //get beverage select by user
        vendingMachine.selectBeverage(selectBeverageNumber);
        //request notes from the users
        vendingMachine.displayEnterNotesMessage();
        //get notes from users
        String userEnteredNotes = scanner.nextLine();
        //convert to array
        int[] enteredNotes =Note.parseNotes(userEnteredNotes);
        //passing notes to the machine
        vendingMachine.enterNotes(selectBeverageNumber);
        //
        vendingMachine.displayChangeMessage();
    }
}
