/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public interface VendingMachine {

    public void displayBeverage();

    public void selectBeverage(int beverage);

    public void displayEnterNotesMessage();

    public void enterNotes(int... notes);

    public void displayChangeMessage();
}
