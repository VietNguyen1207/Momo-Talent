/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class VendingMachineImplement implements VendingMachine{
    
    private int selectedBeverage;
    private NoteBundle change;

    @Override
    public void displayBeverage() {
        System.out.println("  WELCOME TO BEVERAGE VENDING ");
        System.out.println("Beverage :");
        for (Beverage beverage : Beverage.values()) {
            System.out.println("     "  + beverage.getId()+ " " + beverage.name()+" Price "+beverage.getPrice());
        }
        System.out.println("Please select :");
    }

    @Override
    public void selectBeverage(int beverage) {
        this.selectedBeverage = beverage;
    }

    @Override
    public void displayEnterNotesMessage() {
        System.out.println("Please insert note follow these instructions");
        System.out.println("number of 10.0 note, number of 20.0 note, number of 50.0 note, number of 100.0 note, num of 200.0 note");
        System.out.println("                      ");
        System.out.println("For example: if you want to insert two 20 thousand note : 0,2,0,0,0"); //input using the line 34 order
        System.out.println("Please insert note");
    }

    @Override
    public void enterNotes(int... notes) {
        Calculator calculator = new CalculatorImplement();
        Beverage beverage = Beverage.valueOf(this.selectedBeverage);
        int total = calculator.calculateTotal(new NoteBundle(notes));
        float changeAmount = total - beverage.getPrice();
        this.change = calculator.calculateChange(changeAmount);
    }

    @Override
    public void displayChangeMessage() {
        System.out.println("                        ");
        System.out.println("Your change is "+ change.getTotal() +"splitted as follow");
        System.out.println("   200 thousand notes"+ change.number200ThousandNotes);
        System.out.println("   100 thousand notes"+ change.number100ThousandNotes);
        System.out.println("   50 thousand notes"+ change.number50ThousandNotes);
        System.out.println("   20 thousand notes"+ change.number20ThousandNotes);
        System.out.println("   10 thousand notes"+ change.number10ThousandNotes);
    }
    
}
