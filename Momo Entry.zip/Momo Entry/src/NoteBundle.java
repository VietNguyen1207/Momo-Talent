/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
 public class NoteBundle {
    
     public int number10ThousandNotes;
     public int number20ThousandNotes;
     public int number50ThousandNotes;
     public int number100ThousandNotes;
     public int number200ThousandNotes;
     
     public NoteBundle(int... enteredNotes){
         this.number10ThousandNotes = enteredNotes[0];
         this.number20ThousandNotes = enteredNotes[1];
         this.number50ThousandNotes = enteredNotes[2];
         this.number100ThousandNotes = enteredNotes[3];
         this.number200ThousandNotes = enteredNotes[4];
         
     }
     
     public int getTotal(){
         int total = 0;
         total = total + this.number10ThousandNotes*5;
         total = total + this.number20ThousandNotes*20;
         total = total + this.number50ThousandNotes*50;
         total = total + this.number100ThousandNotes*100;
         total = total + this.number200ThousandNotes*200;
         return total;
     }
}
